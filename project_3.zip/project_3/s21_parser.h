#ifndef S21_PARSER_H
#define S21_PARSER_H

int infix_to_rpn(const char *input, char *output);

#endif  